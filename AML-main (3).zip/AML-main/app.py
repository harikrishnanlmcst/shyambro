from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL

app = Flask(__name__, template_folder='template')
app.secret_key = 'Hari@2001'  # Set a secret key for session management

# Configure MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Hari@2001'
app.config['MYSQL_DB'] = 'aml'

mysql = MySQL(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    if request.method == 'POST':
        userDetails = request.form
        userType = userDetails.get('user-type')

        if userType == 'bank':
            BankId = userDetails.get('bank-id')
            if BankId:
                Name = userDetails.get('bank-name')
                Branch = userDetails.get('bank-branch')
                Address = userDetails.get('bank-address')
                ContactNumber = userDetails.get('bank-contact-number')
                Email = userDetails.get('bank-email')
                UserName = userDetails.get('bank-username')
                Password = userDetails.get('bank-password')
                
                cur = mysql.connection.cursor()
                try:
                    cur.execute("INSERT INTO aml_bankdetails (bank_id, bank_name, bank_branch, bank_address, bank_contactnumber, bank_emailid, bank_username, bank_password) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                                (BankId, Name, Branch, Address, ContactNumber, Email, UserName, Password))
                    mysql.connection.commit()
                    return redirect(url_for('index', message='Registration successful'))  
                except mysql.connection.IntegrityError as e:
                    print(f"Error inserting bank details: {e}")
                    mysql.connection.rollback()
            else:
                print("Bank ID is missing.")

        elif userType == 'customer':
            CustomerId = userDetails.get('customer-id')
            cur = mysql.connection.cursor()
            cur.execute("""
                INSERT INTO aml_customeraccountdetails 
                (customerid, customer_name, customer_dob, customer_address, customer_nationality, customer_contactnumber,
                customer_accountdetails, customer_emailid, customer_username, customer_password,customer_bankname,customer_accounttype,customer_accountname,customer_currentbalance) 
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%s,%s,%s,%s)
                """, 
                (CustomerId, userDetails.get('customer-name'), userDetails.get('customer-dob'), 
                 userDetails.get('customer-address'), userDetails.get('customer-nationality'), 
                 userDetails.get('customer-contact-number'), userDetails.get('customer-account-details'), 
                 userDetails.get('customer-email'), userDetails.get('customer-username'), 
                 userDetails.get('customer-password'), userDetails.get('customer-bankname'), 
                 userDetails.get('customer-accounttype'), userDetails.get('customer-accountname'), 
                 userDetails.get('customer-currentbalance')))
            mysql.connection.commit()
            cur.close()

            return redirect(url_for('index', message='Registration successful'))  

    return 'Registration failed. Please try again.'

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM aml_bankdetails WHERE bank_username = %s AND bank_password = %s", (username, password))
        bank_user = cur.fetchone()
        cur.execute("SELECT * FROM aml_customeraccountdetails WHERE customer_username = %s AND customer_password = %s", (username, password))
        customer_user = cur.fetchone()
        cur.close()

        if bank_user:
            session['username'] = username
            return redirect(url_for('bank_home'))
        elif customer_user:
            session['username'] = username
            return redirect(url_for('customer_home'))
        else:
            return redirect(url_for('index', message='Login failed. Please try again.'))

@app.route('/bank')
def bank_home():
    if 'username' in session:
        return render_template('bank.html')
    return redirect(url_for('index'))

@app.route('/customer')
def customer_home():
    if 'username' in session:
        return render_template('customer.html')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
