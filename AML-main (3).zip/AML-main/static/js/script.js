document.addEventListener('DOMContentLoaded', function () {
    // Add event listener to the register button
    document.getElementById('register-button').addEventListener('click', function () {
      // Perform validation here (if needed)
      
      // Redirect to the login page (index.html)
      window.location.href = 'index.html'; // Change 'index.html' to the correct path if needed
    });
  });
  